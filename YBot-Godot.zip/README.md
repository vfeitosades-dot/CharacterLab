# Y Bot Baseplate
Godot 4.4.1, Windows x64, Compatibility (OpenGL). Model and four motions: original FBX files supplied by the user, renamed only. WASD, Shift, Space, mouse, Escape. Standing idle is the relaxed opening pose of the provided jump. Horizontal travel in the hips is adjusted to avoid double motion.
Open project.godot with Godot 4.4.1 and run F6/F5. Export preset: Windows Desktop, embedded PCK. Requires matching Godot export templates. The project has not been run or exported in the ChatGPT environment.
