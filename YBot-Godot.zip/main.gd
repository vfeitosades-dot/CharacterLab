extends Node3D

const MODEL = preload("res://assets/ybot.fbx")
const WALK = preload("res://assets/walk.fbx")
const RUN = preload("res://assets/run.fbx")
const JUMP = preload("res://assets/jump.fbx")
const RUN_JUMP = preload("res://assets/run_jump.fbx")

var body: CharacterBody3D
var pivot: Node3D
var model: Node3D
var skeleton: Skeleton3D
var animator: AnimationPlayer
var library := AnimationLibrary.new()
var camera: Camera3D
var yaw := 0.0
var pitch := -0.22
var jump_clock := -1.0
var jump_launch := 0.0
var jump_end := 0.0
var jump_air := false
var current := ""
var jump_was_pressed := false
var ready_ok := false

func _ready() -> void:
	make_world()
	make_player()
	if skeleton != null:
		prepare_animations()
	ready_ok = library.has_animation("idle") and library.has_animation("walk") and library.has_animation("run") and library.has_animation("jump") and library.has_animation("run_jump")
	if not ready_ok:
		push_error("Y Bot: required animation or skeleton missing")
	if "--smoke-test" in OS.get_cmdline_user_args():
		print("YBOT_ANIMATIONS=", library.get_animation_list())
		get_tree().quit(0 if ready_ok else 1)
		return
	if not ready_ok:
		return
	play_clip("idle", 0.0)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func make_world() -> void:
	var env := WorldEnvironment.new()
	var settings := Environment.new()
	settings.background_mode = Environment.BG_COLOR
	settings.background_color = Color(0.59, 0.72, 0.84)
	settings.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	settings.ambient_light_color = Color(0.87, 0.91, 1.0)
	settings.ambient_light_energy = 0.75
	env.environment = settings
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-53, -35, 0)
	sun.light_energy = 1.1
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 35.0
	add_child(sun)
	var ground := StaticBody3D.new()
	ground.position.y = -0.25
	add_child(ground)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(100, 0.5, 100)
	collision.shape = shape
	ground.add_child(collision)
	var surface := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = shape.size
	surface.mesh = box
	var material := ShaderMaterial.new()
	var shader := Shader.new()
	shader.code = """shader_type spatial;
render_mode diffuse_lambert;
varying vec3 world_pos;
void vertex(){world_pos=(MODEL_MATRIX*vec4(VERTEX,1.0)).xyz;}
void fragment(){
 vec2 grid=abs(fract(world_pos.xz)-0.5);
 float edge=max(grid.x,grid.y);
 float line=smoothstep(0.465,0.495,edge);
 ALBEDO=mix(vec3(0.40,0.45,0.43),vec3(0.30,0.35,0.33),line*0.65);
 ROUGHNESS=0.92;
}"""
	material.shader = shader
	surface.material_override = material
	ground.add_child(surface)

func make_player() -> void:
	body = CharacterBody3D.new()
	body.position = Vector3(0, 0.03, 0)
	body.floor_snap_length = 0.15
	add_child(body)
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.78
	var collider := CollisionShape3D.new()
	collider.shape = capsule
	collider.position.y = 0.89
	body.add_child(collider)
	pivot = Node3D.new()
	body.add_child(pivot)
	model = MODEL.instantiate() as Node3D
	pivot.add_child(model)
	skeleton = find_skeleton(model)
	var old_player := find_animator(model)
	if old_player != null:
		old_player.stop()
		old_player.active = false
	animator = AnimationPlayer.new()
	animator.name = "CharacterAnimations"
	model.add_child(animator)
	animator.root_node = NodePath("..")
	animator.add_animation_library("", library)
	camera = Camera3D.new()
	camera.fov = 65.0
	camera.current = true
	add_child(camera)
	update_camera(1.0)
	var layer := CanvasLayer.new()
	add_child(layer)
	var label := Label.new()
	label.text = "WASD  Andar   |   Shift  Correr   |   Espaço  Pular   |   Mouse  Câmera   |   Esc  Cursor"
	label.position = Vector2(14, 12)
	label.add_theme_font_size_override("font_size", 15)
	label.add_theme_color_override("font_shadow_color", Color(0.08, 0.09, 0.10))
	label.add_theme_constant_override("shadow_offset_x", 1)
	label.add_theme_constant_override("shadow_offset_y", 1)
	layer.add_child(label)

func find_skeleton(node: Node) -> Skeleton3D:
	if node is Skeleton3D:
		return node as Skeleton3D
	for child in node.get_children():
		var found := find_skeleton(child)
		if found != null:
			return found
	return null

func find_animator(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node as AnimationPlayer
	for child in node.get_children():
		var found := find_animator(child)
		if found != null:
			return found
	return null

func prepare_animations() -> void:
	import_clip(WALK, "walk", true)
	import_clip(RUN, "run", true)
	import_clip(JUMP, "jump", false)
	import_clip(RUN_JUMP, "run_jump", false)
	if library.has_animation("jump"):
		var idle := library.get_animation("jump").duplicate(true) as Animation
		# Use the relaxed opening pose in the supplied standing-jump animation.
		for track in range(idle.get_track_count()):
			for key in range(idle.track_get_key_count(track)-1, 0, -1):
				idle.track_remove_key(track, key)
			if idle.track_get_key_count(track) > 0:
				idle.track_set_key_time(track, 0, 0.0)
		idle.length = 0.5
		idle.loop_mode = Animation.LOOP_LINEAR
		library.add_animation("idle", idle)

func import_clip(scene: PackedScene, clip_name: String, looping: bool) -> void:
	var source := scene.instantiate()
	var source_anim := find_animator(source)
	if source_anim == null:
		source.free()
		return
	var chosen: Animation = null
	var score := -1
	for anim_name in source_anim.get_animation_list():
		if str(anim_name).to_lower().contains("reset"):
			continue
		var candidate := source_anim.get_animation(anim_name)
		var rank: int = candidate.get_track_count()
		if str(anim_name).to_lower().contains("mixamo"):
			rank += 10000
		if rank > score:
			score = rank
			chosen = candidate
	if chosen == null:
		source.free()
		return
	var clip := chosen.duplicate(true) as Animation
	var skeleton_path := str(model.get_path_to(skeleton))
	for track in range(clip.get_track_count()-1, -1, -1):
		var path := clip.track_get_path(track)
		if path.get_subname_count() == 0:
			clip.remove_track(track)
			continue
		var bone := str(path.get_subname(0))
		if skeleton.find_bone(bone) == -1:
			clip.remove_track(track)
			continue
		clip.track_set_path(track, NodePath(skeleton_path + ":" + bone))
		if clip.track_get_type(track) == Animation.TYPE_POSITION_3D and bone.to_lower().ends_with("hips"):
			remove_travel(clip, track)
	source.free()
	if clip.get_track_count() == 0:
		return
	clip.loop_mode = Animation.LOOP_LINEAR if looping else Animation.LOOP_NONE
	library.add_animation(clip_name, clip)

func remove_travel(clip: Animation, track: int) -> void:
	var count := clip.track_get_key_count(track)
	if count < 2:
		return
	var first: Vector3 = clip.track_get_key_value(track, 0)
	var last: Vector3 = clip.track_get_key_value(track, count-1)
	var t0 := clip.track_get_key_time(track, 0)
	var duration := maxf(0.001, clip.track_get_key_time(track, count-1) - t0)
	var drift := last - first
	drift.y = 0.0
	for key in range(count):
		var value: Vector3 = clip.track_get_key_value(track, key)
		var fraction := (clip.track_get_key_time(track, key)-t0)/duration
		clip.track_set_key_value(track, key, value-drift*fraction)

func play_clip(name: String, blend: float = 0.16) -> void:
	if name != current and library.has_animation(name):
		current = name
		animator.play(name, blend)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		yaw -= event.relative.x * 0.003
		pitch = clampf(pitch-event.relative.y*0.003, -1.05, 0.30)
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _physics_process(delta: float) -> void:
	if not ready_ok:
		return
	var x := float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A))
	var z := float(Input.is_physical_key_pressed(KEY_S))-float(Input.is_physical_key_pressed(KEY_W))
	var dir := Vector3(x, 0, z).limit_length(1.0).rotated(Vector3.UP, yaw)
	var moving := dir.length_squared() > 0.01
	var running := moving and Input.is_physical_key_pressed(KEY_SHIFT)
	var speed := 4.25 if running else 1.65
	var jump_pressed := Input.is_physical_key_pressed(KEY_SPACE)
	if jump_pressed and not jump_was_pressed and body.is_on_floor() and jump_clock < 0.0:
		jump_clock = 0.0
		jump_air = false
		var jump_name := "run_jump" if running else "jump"
		jump_launch = 0.025 if running else 0.78
		jump_end = library.get_animation(jump_name).length - (0.03 if running else 0.25)
		play_clip(jump_name, 0.08)
	jump_was_pressed = jump_pressed
	if jump_clock >= 0.0:
		jump_clock += delta
		if not jump_air and jump_clock >= jump_launch:
			body.velocity.y = 3.15
			jump_air = true
		elif not jump_air:
			if current == "jump":
				dir = Vector3.ZERO
				moving = false
		if jump_clock >= jump_end and body.is_on_floor():
			jump_clock = -1.0
	if not body.is_on_floor():
		body.velocity.y -= 10.5*delta
	elif body.velocity.y < 0.0:
		body.velocity.y = 0.0
	var target := dir*speed
	body.velocity.x = move_toward(body.velocity.x, target.x, 16.0*delta)
	body.velocity.z = move_toward(body.velocity.z, target.z, 16.0*delta)
	if moving:
		pivot.rotation.y = lerp_angle(pivot.rotation.y, atan2(dir.x,dir.z), minf(1.0,delta*12.0))
	body.move_and_slide()
	if jump_clock < 0.0:
		if moving:
			play_clip("run" if running else "walk")
		else:
			play_clip("idle")
	if body.position.y < -8.0:
		body.position = Vector3(0,0.05,0)
		body.velocity = Vector3.ZERO
		jump_clock = -1.0

func _process(delta: float) -> void:
	if camera != null:
		update_camera(1.0-exp(-12.0*delta))

func update_camera(weight: float) -> void:
	var focus := body.global_position + Vector3(0, 1.25, 0)
	var offset := Vector3(0, 0, 4.6).rotated(Vector3.RIGHT,pitch).rotated(Vector3.UP,yaw)
	camera.global_position = camera.global_position.lerp(focus+offset,weight)
	camera.look_at(focus, Vector3.UP)
