extends Node3D

const MODEL = preload("res://assets/ybot.fbx")
const IDLE = preload("res://assets/idle.fbx")
const WALK = preload("res://assets/walk.fbx")
const RUN = preload("res://assets/run.fbx")
const JUMP = preload("res://assets/jump.fbx")
const RUN_JUMP = preload("res://assets/run_jump.fbx")

var body: CharacterBody3D
var pivot: Node3D
var model: Node3D
var skeleton: Skeleton3D
var animator: AnimationPlayer
var library := AnimationLibrary.new()
var camera: Camera3D
var yaw := 0.0
var pitch := -0.22
const WALK_SPEED := 1.60
const RUN_SPEED := 4.24
const GRAVITY := 9.81
const TURN_SPEED := 9.5
var jump_clock := -1.0
var jump_launch := 0.0
var jump_land := 0.0
var jump_end := 0.0
var jump_air := false
var jump_landed := false
var jump_buffer := 0.0
var locomotion_rate := 1.0
var current := ""
var jump_was_pressed := false
var ready_ok := false

func _ready() -> void:
	make_world()
	make_player()
	if skeleton != null:
		prepare_animations()
	ready_ok = library.has_animation("idle") and library.has_animation("walk") and library.has_animation("run") and library.has_animation("jump") and library.has_animation("run_jump")
	if not ready_ok:
		push_error("Y Bot: required animation or skeleton missing")
	if "--smoke-test" in OS.get_cmdline_user_args():
		print("YBOT_V2_ANIMATIONS=", library.get_animation_list())
		get_tree().quit(0 if ready_ok else 1)
		return
	if not ready_ok:
		return
	play_clip("idle", 0.0)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func make_world() -> void:
	var env := WorldEnvironment.new()
	var settings := Environment.new()
	settings.background_mode = Environment.BG_COLOR
	settings.background_color = Color(0.59, 0.72, 0.84)
	settings.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	settings.ambient_light_color = Color(0.87, 0.91, 1.0)
	settings.ambient_light_energy = 0.75
	env.environment = settings
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-53, -35, 0)
	sun.light_energy = 1.1
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 35.0
	add_child(sun)
	var ground := StaticBody3D.new()
	ground.position.y = -0.25
	add_child(ground)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(100, 0.5, 100)
	collision.shape = shape
	ground.add_child(collision)
	var surface := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = shape.size
	surface.mesh = box
	var material := ShaderMaterial.new()
	var shader := Shader.new()
	shader.code = """shader_type spatial;
render_mode diffuse_lambert;
varying vec3 world_pos;
void vertex(){world_pos=(MODEL_MATRIX*vec4(VERTEX,1.0)).xyz;}
void fragment(){
 vec2 grid=abs(fract(world_pos.xz)-0.5);
 float edge=max(grid.x,grid.y);
 float line=smoothstep(0.465,0.495,edge);
 ALBEDO=mix(vec3(0.40,0.45,0.43),vec3(0.30,0.35,0.33),line*0.65);
 ROUGHNESS=0.92;
}"""
	material.shader = shader
	surface.material_override = material
	ground.add_child(surface)

func make_player() -> void:
	body = CharacterBody3D.new()
	body.position = Vector3(0, 0.03, 0)
	body.floor_snap_length = 0.18
	body.floor_stop_on_slope = true
	body.floor_constant_speed = true
	add_child(body)
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.78
	var collider := CollisionShape3D.new()
	collider.shape = capsule
	collider.position.y = 0.89
	body.add_child(collider)
	pivot = Node3D.new()
	body.add_child(pivot)
	model = MODEL.instantiate() as Node3D
	pivot.add_child(model)
	skeleton = find_skeleton(model)
	var old_player := find_animator(model)
	if old_player != null:
		old_player.stop()
		old_player.active = false
	animator = AnimationPlayer.new()
	animator.name = "CharacterAnimations"
	model.add_child(animator)
	animator.root_node = NodePath("..")
	animator.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_PHYSICS
	animator.add_animation_library("", library)
	camera = Camera3D.new()
	camera.fov = 65.0
	camera.current = true
	add_child(camera)
	update_camera(1.0)
	var layer := CanvasLayer.new()
	add_child(layer)
	var label := Label.new()
	label.text = "WASD  Andar   |   Shift  Correr   |   Espaço  Pular   |   Mouse  Câmera   |   Esc  Cursor"
	label.position = Vector2(14, 12)
	label.add_theme_font_size_override("font_size", 15)
	label.add_theme_color_override("font_shadow_color", Color(0.08, 0.09, 0.10))
	label.add_theme_constant_override("shadow_offset_x", 1)
	label.add_theme_constant_override("shadow_offset_y", 1)
	layer.add_child(label)

func find_skeleton(node: Node) -> Skeleton3D:
	if node is Skeleton3D:
		return node as Skeleton3D
	for child in node.get_children():
		var found := find_skeleton(child)
		if found != null:
			return found
	return null

func find_animator(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node as AnimationPlayer
	for child in node.get_children():
		var found := find_animator(child)
		if found != null:
			return found
	return null

func prepare_animations() -> void:
	import_clip(IDLE, "idle", true)
	import_clip(WALK, "walk", true)
	import_clip(RUN, "run", true)
	import_clip(JUMP, "jump", false)
	import_clip(RUN_JUMP, "run_jump", false)

func import_clip(scene: PackedScene, clip_name: String, looping: bool) -> void:
	var source := scene.instantiate()
	var source_anim := find_animator(source)
	if source_anim == null:
		source.free()
		return
	var chosen: Animation = null
	var score := -1
	for anim_name in source_anim.get_animation_list():
		if str(anim_name).to_lower().contains("reset"):
			continue
		var candidate := source_anim.get_animation(anim_name)
		var rank: int = candidate.get_track_count()
		if str(anim_name).to_lower().contains("mixamo"):
			rank += 10000
		if rank > score:
			score = rank
			chosen = candidate
	if chosen == null:
		source.free()
		return
	var clip := chosen.duplicate(true) as Animation
	var skeleton_path := str(model.get_path_to(skeleton))
	for track in range(clip.get_track_count()-1, -1, -1):
		var path := clip.track_get_path(track)
		if path.get_subname_count() == 0:
			clip.remove_track(track)
			continue
		var bone := str(path.get_subname(0))
		if skeleton.find_bone(bone) == -1:
			clip.remove_track(track)
			continue
		clip.track_set_path(track, NodePath(skeleton_path + ":" + bone))
		if clip.track_get_type(track) == Animation.TYPE_POSITION_3D and bone.to_lower().ends_with("hips"):
			remove_travel(clip, track)
			if clip_name == "jump":
				remove_airborne_lift(clip, track, 0.84, 1.43)
			elif clip_name == "run_jump":
				remove_airborne_lift(clip, track, 0.04, 0.64)
	source.free()
	if clip.get_track_count() == 0:
		return
	if clip_name == "jump":
		retime_standing_jump(clip)
	clip.loop_mode = Animation.LOOP_LINEAR if looping else Animation.LOOP_NONE
	library.add_animation(clip_name, clip)

func remove_travel(clip: Animation, track: int) -> void:
	var count := clip.track_get_key_count(track)
	if count < 2:
		return
	var first: Vector3 = clip.track_get_key_value(track, 0)
	var last: Vector3 = clip.track_get_key_value(track, count-1)
	var t0 := clip.track_get_key_time(track, 0)
	var duration := maxf(0.001, clip.track_get_key_time(track, count-1) - t0)
	var drift := last - first
	drift.y = 0.0
	for key in range(count):
		var value: Vector3 = clip.track_get_key_value(track, key)
		var fraction := (clip.track_get_key_time(track, key)-t0)/duration
		clip.track_set_key_value(track, key, value-drift*fraction)

# Preserve the original crouch and landing pose, but let CharacterBody3D
# supply the main vertical trajectory instead of adding the FBX's jump twice.
func remove_airborne_lift(clip: Animation, track: int, takeoff: float, landing: float) -> void:
	var count := clip.track_get_key_count(track)
	if count < 2:
		return
	var start_value: Vector3 = clip.position_track_interpolate(track, takeoff)
	var end_value: Vector3 = clip.position_track_interpolate(track, landing)
	for key in range(count):
		var time := clip.track_get_key_time(track, key)
		if time <= takeoff or time >= landing:
			continue
		var value: Vector3 = clip.track_get_key_value(track, key)
		var fraction := (time-takeoff)/(landing-takeoff)
		var baseline := lerpf(start_value.y, end_value.y, fraction)
		# Leave a small part of the hip motion for natural pose articulation.
		value.y -= maxf(0.0, value.y-baseline)*0.90
		clip.track_set_key_value(track, key, value)

# The supplied standing jump has a long anticipation. Compress it to 220 ms,
# preserve its approximately 590 ms flight, and shorten the recovery.
func jump_time(t: float) -> float:
	if t <= 0.84:
		return t*(0.22/0.84)
	if t <= 1.43:
		return 0.22+(t-0.84)
	return 0.81+(t-1.43)*0.48

func retime_standing_jump(clip: Animation) -> void:
	var duration := jump_time(clip.length)
	for track in range(clip.get_track_count()):
		for key in range(clip.track_get_key_count(track)):
			var new_time := jump_time(clip.track_get_key_time(track,key))
			clip.track_set_key_time(track,key,new_time)
	clip.length = duration

func play_clip(name: String, blend: float = 0.16) -> void:
	if name == current or not library.has_animation(name):
		return
	var old := current
	current = name
	animator.play(name, blend)
	if name == "jump" or name == "run_jump" or name == "idle":
		locomotion_rate = 1.0
		animator.speed_scale = 1.0
	elif old == "idle" or old.contains("jump"):
		locomotion_rate = 0.85
		animator.speed_scale = locomotion_rate

func horizontal_velocity() -> Vector3:
	return Vector3(body.velocity.x, 0.0, body.velocity.z)

func start_jump(running: bool) -> void:
	var clip_name := "run_jump" if running else "jump"
	jump_clock = 0.0
	jump_air = false
	jump_landed = false
	jump_launch = 0.04 if running else 0.22
	jump_land = 0.64 if running else 0.81
	jump_end = library.get_animation(clip_name).length - (0.06 if running else 0.15)
	jump_buffer = 0.0
	play_clip(clip_name, 0.10)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		yaw -= event.relative.x * 0.003
		pitch = clampf(pitch-event.relative.y*0.003, -1.05, 0.30)
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _physics_process(delta: float) -> void:
	if not ready_ok:
		return
	var x := float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A))
	var z := float(Input.is_physical_key_pressed(KEY_S))-float(Input.is_physical_key_pressed(KEY_W))
	var dir := Vector3(x, 0, z).limit_length(1.0).rotated(Vector3.UP, yaw)
	var moving := dir.length_squared() > 0.01
	var running := moving and Input.is_physical_key_pressed(KEY_SHIFT)
	var speed := RUN_SPEED if running else WALK_SPEED
	var planar := horizontal_velocity()
	var grounded := body.is_on_floor()
	var jump_pressed := Input.is_physical_key_pressed(KEY_SPACE)
	if jump_pressed and not jump_was_pressed:
		jump_buffer = 0.13
	else:
		jump_buffer = maxf(0.0, jump_buffer-delta)
	jump_was_pressed = jump_pressed
	if grounded and jump_clock < 0.0 and jump_buffer > 0.0:
		start_jump(planar.length() > 2.25)

	# Accelerate with momentum rather than snapping to the target speed.
	var target := dir*speed
	var acceleration := 6.7 if not running else 6.0
	if not moving:
		acceleration = 9.5
	elif planar.length() > 0.15 and planar.normalized().dot(dir) < 0.45:
		acceleration = 8.0
	if jump_clock >= 0.0 and not jump_air and current == "jump":
		target = Vector3.ZERO
		acceleration = 12.0
	elif not grounded or (jump_air and not jump_landed):
		# Carry momentum through the air; retain only gentle steering.
		acceleration = 1.7 if moving else 0.0
		if not moving:
			target = planar
	elif jump_landed and current == "jump":
		target *= 0.60
	planar = planar.move_toward(target, acceleration*delta)
	body.velocity.x = planar.x
	body.velocity.z = planar.z

	# Rotate gradually, more slowly when airborne or moving fast.
	var facing := planar if planar.length() > 0.12 else dir
	if facing.length_squared() > 0.01:
		var desired := atan2(facing.x, facing.z)
		var turn := TURN_SPEED if grounded else 4.0
		pivot.rotation.y = lerp_angle(pivot.rotation.y, desired, 1.0-exp(-turn*delta))

	var launched_now := false
	if jump_clock >= 0.0:
		jump_clock += delta
		if not jump_air and jump_clock >= jump_launch:
			# Set the impulse from the FBX's airborne interval.
			body.velocity.y = GRAVITY*(jump_land-jump_launch)*0.5
			jump_air = true
			launched_now = true
	if not grounded and not launched_now:
		body.velocity.y -= GRAVITY*delta
	elif grounded and not launched_now and body.velocity.y < 0.0:
		body.velocity.y = 0.0
	body.move_and_slide()
	if jump_air and not jump_landed and not launched_now and body.is_on_floor() and body.velocity.y <= 0.0:
		jump_landed = true
	if jump_clock >= 0.0 and jump_landed and jump_clock >= jump_end:
		jump_clock = -1.0
		jump_air = false
		jump_landed = false

	if jump_clock < 0.0:
		var actual_speed := horizontal_velocity().length()
		# Hysteresis keeps tiny velocity changes from flickering animations.
		if actual_speed < (0.17 if current == "idle" else 0.09):
			play_clip("idle", 0.20)
		elif actual_speed > (2.30 if current == "run" else 2.65):
			play_clip("run", 0.18)
		else:
			play_clip("walk", 0.18)
		# Match the pace to the measured original FBX stride speed.
		var rate := 1.0
		if current == "walk":
			rate = clampf(actual_speed/WALK_SPEED, 0.50, 1.45)
		elif current == "run":
			rate = clampf(actual_speed/RUN_SPEED, 0.60, 1.18)
		locomotion_rate = lerpf(locomotion_rate,rate,1.0-exp(-10.0*delta))
		animator.speed_scale = locomotion_rate
	if body.position.y < -8.0:
		body.position = Vector3(0,0.05,0)
		body.velocity = Vector3.ZERO
		jump_clock = -1.0
		jump_air = false
		jump_landed = false
		play_clip("idle", 0.0)

func _process(delta: float) -> void:
	if camera != null:
		update_camera(1.0-exp(-12.0*delta))

func update_camera(weight: float) -> void:
	var focus := body.global_position + Vector3(0, 1.25, 0)
	var offset := Vector3(0, 0, 4.6).rotated(Vector3.RIGHT,pitch).rotated(Vector3.UP,yaw)
	camera.global_position = camera.global_position.lerp(focus+offset,weight)
	camera.look_at(focus, Vector3.UP)
